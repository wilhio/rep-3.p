// JavaScript to enhance the AI Literacy & Prompting Techniques webpage

document.addEventListener("DOMContentLoaded", function() {
    // Scroll to top functionality
    const scrollToTopBtn = document.createElement("button");
    scrollToTopBtn.textContent = "Scroll to Top";
    scrollToTopBtn.style.position = "fixed";
    scrollToTopBtn.style.bottom = "20px";
    scrollToTopBtn.style.right = "20px";
    scrollToTopBtn.style.padding = "10px 15px";
    scrollToTopBtn.style.backgroundColor = "#333";
    scrollToTopBtn.style.color = "#fff";
    scrollToTopBtn.style.border = "none";
    scrollToTopBtn.style.borderRadius = "5px";
    scrollToTopBtn.style.cursor = "pointer";
    scrollToTopBtn.style.display = "none";
    document.body.appendChild(scrollToTopBtn);

    // Show or hide scroll to top button on scroll
    window.addEventListener("scroll", function() {
        if (window.scrollY > 300) {
            scrollToTopBtn.style.display = "block";
        } else {
            scrollToTopBtn.style.display = "none";
        }
    });

    // Scroll to top on button click
    scrollToTopBtn.addEventListener("click", function() {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    // Highlight sections when they are in the viewport
    const sections = document.querySelectorAll("section");
    window.addEventListener("scroll", function() {
        sections.forEach(section => {
            const rect = section.getBoundingClientRect();
            if (rect.top >= 0 && rect.bottom <= window.innerHeight) {
                section.style.backgroundColor = "#e6f7ff";
            } else {
                section.style.backgroundColor = "#fff";
            }
        });
    });

    // Play/pause video on hover
    const videos = document.querySelectorAll("video");
    videos.forEach(video => {
        video.addEventListener("mouseenter", function() {
            video.play();
        });
        video.addEventListener("mouseleave", function() {
            video.pause();
        });
    });

    // Toggle visibility of audio section
    const audioToggleBtn = document.createElement("button");
    audioToggleBtn.textContent = "Toggle Audio Section";
    audioToggleBtn.style.position = "fixed";
    audioToggleBtn.style.bottom = "60px";
    audioToggleBtn.style.right = "20px";
    audioToggleBtn.style.padding = "10px 15px";
    audioToggleBtn.style.backgroundColor = "#0066cc";
    audioToggleBtn.style.color = "#fff";
    audioToggleBtn.style.border = "none";
    audioToggleBtn.style.borderRadius = "5px";
    audioToggleBtn.style.cursor = "pointer";
    document.body.appendChild(audioToggleBtn);

    const audioSection = document.querySelector("section h2 + audio").parentElement;
    audioToggleBtn.addEventListener("click", function() {
        if (audioSection.style.display === "none" || audioSection.style.display === "") {
            audioSection.style.display = "block";
        } else {
            audioSection.style.display = "none";
        }
    });
});
